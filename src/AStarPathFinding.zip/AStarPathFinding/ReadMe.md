# A* Search Algorithm
Loren Arthur, Samuel Monroe

## Requirements
* numpy
* pygame
    *pygame is in the ubuntu repositories under python-pygame

## Instructions:
* Run 'python main.py' in a the directory of the code

## Notes:
* If pygame doesn't run there is an image of the output included

## Coordinate Output

Coordinates (1,1), g_score: 0

Coordinates (2,1), g_score: 1

Coordinates (3,1), g_score: 2

Coordinates (3,2), g_score: 3

Coordinates (3,3), g_score: 4

Coordinates (3,4), g_score: 5

Coordinates (4,4), g_score: 6

Coordinates (4,5), g_score: 7

Coordinates (4,6), g_score: 8

Coordinates (4,7), g_score: 9

Coordinates (4,8), g_score: 10

Coordinates (3,8), g_score: 11

Coordinates (2,8), g_score: 12

Coordinates (2,9), g_score: 13

Coordinates (2,10), g_score: 14

Coordinates (2,11), g_score: 15

Coordinates (3,11), g_score: 16

Coordinates (4,11), g_score: 17

Coordinates (4,12), g_score: 18

Coordinates (4,13), g_score: 19

Coordinates (4,14), g_score: 20

Coordinates (4,15), g_score: 21

Coordinates (4,16), g_score: 22

Coordinates (4,17), g_score: 23

Coordinates (5,17), g_score: 24

Coordinates (6,17), g_score: 25

Coordinates (7,17), g_score: 26

Coordinates (7,16), g_score: 27

Coordinates (8,16), g_score: 28

Coordinates (8,15), g_score: 29

Coordinates (9,15), g_score: 30

Coordinates (10,15), g_score: 31

Coordinates (11,15), g_score: 32

Coordinates (12,15), g_score: 33

Coordinates (13,15), g_score: 34

Coordinates (14,15), g_score: 35

Coordinates (15,15), g_score: 36

Coordinates (16,15), g_score: 37

Coordinates (16,14), g_score: 38

Coordinates (17,14), g_score: 39

Coordinates (18,14), g_score: 40

Coordinates (19,14), g_score: 41

Coordinates (20,14), g_score: 42

Coordinates (20,15), g_score: 43

Coordinates (20,16), g_score: 44

Coordinates (20,17), g_score: 45

Coordinates (20,18), g_score: 46

Coordinates (20,19), g_score: 47

Coordinates (20,20), g_score: 48